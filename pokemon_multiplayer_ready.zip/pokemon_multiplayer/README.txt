POKEMON BATTLE ROYALE MULTIPLAYER (2 players + 18 bots)

This game requires a Node.js server. Opening index.html directly will not connect.

HOSTING QUICK START (for a Node.js hosting service):
1. Upload this project folder/repository to a hosting service that supports Node.js and WebSockets.
2. Set build/install command: npm install
3. Set start command: npm start
4. The host must use the PORT environment variable and allow WebSockets. This server does.
5. Open the public HTTPS website address from the host on both devices.
6. Both players enter the SAME room code, but different nicknames, and click Join.

For local testing on a computer:
- Install Node.js LTS.
- In this folder, run: npm install
- Then: npm start
- Visit http://localhost:3000
- To test from another device on the same Wi-Fi, use the computer's local IP and port 3000.
